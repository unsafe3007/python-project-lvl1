# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games1', 'brain_games1.games', 'brain_games1.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games1.scripts.brain_calc:main',
                     'brain-even = brain_games1.scripts.brain_even:main',
                     'brain-games = brain_games1.scripts.brain_games:main',
                     'brain-gcd = brain_games1.scripts.brain_gcd:main',
                     'brain-prime = brain_games1.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games1.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'First study project',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/unsafe3007/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/unsafe3007/python-project-lvl1/actions)\n<a href="https://codeclimate.com/github/unsafe3007/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/b0e7094cd06d30776d77/maintainability" /></a>\n\nProject 1: Brain Games.\n\nBrain Even\n<a href="https://asciinema.org/a/2fd1j30Z1wwqac7gsDeHxqNPG" target="_blank"><img src="https://asciinema.org/a/2fd1j30Z1wwqac7gsDeHxqNPG.svg" /></a>\n\nBrain Calc\n<a href="https://asciinema.org/a/F9KbuQ9GaFcY4VDaBYjiGLZlp" target="_blank"><img src="https://asciinema.org/a/F9KbuQ9GaFcY4VDaBYjiGLZlp.svg" /></a>\n\nBrain GCD\n<a href="https://asciinema.org/a/swQY5MxZft3MT8mDDV9S30gV7" target="_blank"><img src="https://asciinema.org/a/swQY5MxZft3MT8mDDV9S30gV7.svg" /></a>\n\nBrain Progression \n<a href="https://asciinema.org/a/mIP94SLFgIcJkZ5uhBtmXKmx1" target="_blank"><img src="https://asciinema.org/a/mIP94SLFgIcJkZ5uhBtmXKmx1.svg" /></a>\n\nBrain Prime\n<a href="https://asciinema.org/a/OysWlpD5MXuGZFvM9AuwHEGwE" target="_blank"><img src="https://asciinema.org/a/OysWlpD5MXuGZFvM9AuwHEGwE.svg" /></a>\n',
    'author': 'Pavel Smushko',
    'author_email': 'unsafe3007@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/unsafe3007/python-project-lvl1',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
