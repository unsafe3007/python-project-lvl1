# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games1', 'brain_games1.games', 'brain_games1.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games1.scripts.brain_calc:main',
                     'brain-even = brain_games1.scripts.brain_even:main',
                     'brain-games = brain_games1.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'python-project-lvl1',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/unsafe3007/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/unsafe3007/python-project-lvl1/actions)\n<a href="https://codeclimate.com/github/unsafe3007/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/b0e7094cd06d30776d77/maintainability" /></a>\n',
    'author': 'Pavel Smushko',
    'author_email': 'unsafe3007@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
