### Hexlet tests and linter status:
[![Actions Status](https://github.com/unsafe3007/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/unsafe3007/python-project-lvl1/actions)
<a href="https://codeclimate.com/github/unsafe3007/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/b0e7094cd06d30776d77/maintainability" /></a>

Project 1: Brain Games.

Brain Even
<a href="https://asciinema.org/a/2fd1j30Z1wwqac7gsDeHxqNPG" target="_blank"><img src="https://asciinema.org/a/2fd1j30Z1wwqac7gsDeHxqNPG.svg" /></a>

Brain Calc
<a href="https://asciinema.org/a/F9KbuQ9GaFcY4VDaBYjiGLZlp" target="_blank"><img src="https://asciinema.org/a/F9KbuQ9GaFcY4VDaBYjiGLZlp.svg" /></a>

Brain GCD
<a href="https://asciinema.org/a/swQY5MxZft3MT8mDDV9S30gV7" target="_blank"><img src="https://asciinema.org/a/swQY5MxZft3MT8mDDV9S30gV7.svg" /></a>
